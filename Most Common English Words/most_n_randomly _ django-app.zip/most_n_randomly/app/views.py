from random import sample, shuffle
from django.shortcuts import render
from django.conf import settings


# One Time Running
filename = 'most-10000-en-fa _ without-nonwords.txt'
lines = open(settings.WORDS_DIR / filename, 'r', encoding='utf-8').readlines()
words = [
    (
        line.split('  ->  ')[0],
        line.strip('\n')
    ) for line in lines
]
shuffle(words)
print(f'⬤ FILENAME: [ "{filename}" ]')
#


def home(request):
    context = {'words': sample(words, 10)}
    return render(request, 'app/home.html', context)