from random import sample
from django.shortcuts import render
from django.conf import settings


#
filename = 'most-10000-en-fa _ without-nonwords.txt' # File Name
lines = open(settings.WORDS_DIR / filename, 'r').readlines()
words = [
    (
        line.split('  ->  ')[0],
        line.strip('\n')
    ) for line in lines
]
print('one time running. (IN HERE #)')
#


def home(request):
    context = {'words': sample(words, 10)}
    return render(request, 'app/home.html', context)