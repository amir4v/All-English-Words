import sqlite3
from read_from_both import get


connection = sqlite3.connect("words.db")
cursor = connection.cursor()

# 3
# for (en, fa) in  get():
#     cursor.execute(f"""
#         INSERT INTO words(en, fa) VALUES('{en}', '{fa}')
#     """)

# 1
# cursor.execute("""
# CREATE TABLE words(
#     id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,
#     en NVARCHAR(255) UNIQUE NOT NULL,
#     fa NVARCHAR(255) NOT NULL
# );
# """)
# # # # - - - -
# 2
# cursor.execute("""
# CREATE INDEX en_index 
# ON words(en);
# """)

connection.commit()

connection.close()

print("Done.")
