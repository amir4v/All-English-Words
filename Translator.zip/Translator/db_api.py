import sqlite3


connection = sqlite3.connect("words.db")
cursor = connection.cursor()

def translate(en=""):
    en = en.strip()
    try:
        result = cursor.execute(f"""
            SELECT fa FROM words WHERE en='{en}' LIMIT 1 ;
        """)
        fa = result.fetchone()[0]
        return fa
    except Exception as e:
        return str(e)+">>>-!"
