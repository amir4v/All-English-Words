all_en = open('All-English-Words.txt', 'r').read().split('\n')
all_fa = open('All-Persian-Words.txt', 'r').read().split('\n')

print(
    f"""
    English words length: {len(all_en)}
    Persian words length: {len(all_fa)}
    """
)

if len(all_en) != len(all_fa):
    exit(0)

def get():
    """
    returns zip(all_en, all_fa), a tuple like this: (en, fa)
    """
    return zip(all_en, all_fa)
