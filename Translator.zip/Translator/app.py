from tkinter import *
import clipboard.clipboard as clipboard
from db_api import translate


tk = Tk()
#
w = 400 # width for the Tk root
h = 50 # height for the Tk root
ws = tk.winfo_screenwidth() # width of the screen
hs = tk.winfo_screenheight() # height of the screen

# calculate x and y coordinates for the Tk root window
x = (ws/2) - (w/2)
y = (hs/2) - (h/2)

# set the dimensions of the screen 
# and where it is placed
tk.geometry('%dx%d+%d+%d' % (w, h, x, y))
#
tk.configure(background='gray')

f = Frame(tk, width=200, height=200)
f.pack()

try:
    en = clipboard.paste()
except:
    en = ""
fa = translate(en)
#
fa = Label(f, text=fa, font=("Sahel", 30))
fa.pack()

tk.mainloop()
